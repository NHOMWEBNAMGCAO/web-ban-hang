﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace Webbanhangshopthoitrang
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            RouteConfig.RegisterRoutes(RouteTable.Routes);
        }
         protected void Session_Start()
        {
            Session["use_admin"] = "";
            Session["use_id"] = "";
            Session["use_fullname"] = "";
            Session["use_img"] = "";
            Session["use_access"] = "";
        }
    }
}
